import pickle  #import pickle module

def pickledump():  #this function will serialize the dictionary data
    favorite_color = {"Ann": "yellow", "John": "red"}
    pickle.dump(favorite_color, open("save.p", "wb"))  # the data is saved to save.p as serialized data

def pickleload():  # this function loads the data from save.p and prints it to the user.
    favorite_color = pickle.load(open("save.p", "rb"))
    print(favorite_color)

#calls the functions
pickledump()
pickleload()