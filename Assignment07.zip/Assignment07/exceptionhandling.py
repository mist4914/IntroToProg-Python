import sys  # import system-specific parameters and functions

try:   # receives input via a try catch statement. If user enters a letter it will raise a ValueError exception
    number = int(input("Please enter a number between 1-10: "))

except ValueError:
    print("Error, please enter numbers only")
    sys.exit()

print("you entered number", number)