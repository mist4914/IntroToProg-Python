#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   MIstrate
# Date:  Feb 10, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   MIstrate, 2/10/2019, Added code to complete assignment 5
#-------------------------------------------------#

#Declare variables and constants
objFile = open ('ToDo.txt', 'r')
strData = ""
dicRow = {}
lstTable = []

#1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

for row in objFile:  # the for loop pulls each row of data and creates a dictionary file from the data within
    strData = row.strip("\n")
    lstData = strData.split(",")
    dicRow = {"Task":lstData[0],"Priority":lstData[1]}
    lstTable.append(dicRow)
objFile.close()

#2- Display a menu of options to the user. It will use the input from the user to determine what loop to initiate.
while(True):
    print ("""
    Options Menu
    1) Show your current to do list.
    2) Add a new item to your list.
    3) Remove an existing item from your list.
    4) Save your changes.
    5) Exit 
    """)
    menuChoice = str(input("Please enter a number to perform one of the below tasks [1 to 5] : "))

#3 - Display the current items
    if (menuChoice.strip() == '1'):
        for row in lstTable:
            print(row["Task"], ",", row["Priority"])
        continue
#4 - Append new items to the table
    elif(menuChoice.strip() == '2'):
        strNewTask = input("Enter the new task: ")
        strNewPriority = input("Enter the priority of the task: ")
        dicNewItem = {"Task":strNewTask,"Priority":strNewPriority}
        lstTable.append(dicNewItem)
        print("\n The task has been added to the list")
        continue
#5 - Index the current items in the table and ask the user to select which item they want deleted
    elif(menuChoice == '3'):
        for item in lstTable:
            print(lstTable.index(item),item)
        intDeleteItem = int(input("Enter the number besides the task to remove it: "))
        del lstTable[intDeleteItem]
        print("\n The task has been removed.")
        continue
#6 - Save tasks to the ToDo.txt file
    elif(menuChoice == '4'):
        objFile = open('ToDo.txt', 'w')
        for row in lstTable:
            strRow = str(row["Task"] +","+ row["Priority"])
            objFile.write(strRow+ "\n")
        objFile.close()
        print("\n The list is saved")
        continue
#7- Exit the program
    elif (menuChoice == '5'):
        break 

