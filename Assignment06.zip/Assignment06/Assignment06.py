#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#    MIstrate, 2/18/2019, Modified script to add functions

#-------------------------------------------------#

#-- Data  --#
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
strData = ""
dicRow = {}
lstTable = []


class ToDo:
#-- Presentation --#
# User can see a Menu
    def display_menu():  # input output
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
    def menu_input():
        menuNumber = str(input("Which option would you like to perform? [1 to 4] - "))
        print()  # adding a new line
        return menuNumber
# User can see data
    def print_current_items():
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

# User can save to file
    def saveinput():
        strSave = str(input("Save this data to file? (y/n) - ")).strip().lower()
        return strSave

    def datasaved():
        input("Data saved to file! Press the [Enter] key to return to menu.")

    def datanotsaved():
        input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")


    def new_item_input(): #input output/presentation
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        return strTask, strPriority

    def remove_item_input():
        strKeyToRemove = input("Which TASK would you like removed? - ")
        return strKeyToRemove
    def taskremoved():
        print('The task was removed')
    def tasknotremoved():
        print("Im sorry, but I could not find that task.")

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
    def open_file():  # processing
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
# Add a new item to the list/Table
    def add_new_item(): #processing
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
# Remove a new item to the list/Table
    def remove_item(): #processing and input output
        blnItemRemoved = False  # Creating a boolean flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            ToDo.taskremoved()
        else:
            ToDo.tasknotremoved()
# Save tasks to the ToDo.txt file
    def saveItem():  #input output and processing
        # 6b Ask if they want save that data
        answer = ToDo.saveinput()
        if answer == 'y':
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            ToDo.datasaved()
        else:
            ToDo.datanotsaved()
#-------------------------------1


#main
ToDo.open_file()
while(True):
    # displays a menu of options (step 2)
    ToDo.display_menu()
    strChoice = ToDo.menu_input()
    # Step 3 - Show current items
    if (strChoice.strip() == '1'):
        ToDo.print_current_items()
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask, strPriority = ToDo.new_item_input()
        ToDo.add_new_item()
        ToDo.print_current_items()
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        ToDo.print_current_items()
        strKeyToRemove = ToDo.remove_item_input()
        ToDo.remove_item()
        ToDo.print_current_items()
        continue #back to menu
    # Step 6 -Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        ToDo.print_current_items()
        ToDo.saveItem()
        continue #to show the menu
    elif (strChoice == '5'):
        break #and Exit the program